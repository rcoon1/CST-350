using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASPCoreFirstApp.Views.Shared
{
    public class _navbarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
