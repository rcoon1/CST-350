﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameDependencyInjectionCore
{
    internal interface IWeapon
    {
        void AttackWithMe();
    }
}
