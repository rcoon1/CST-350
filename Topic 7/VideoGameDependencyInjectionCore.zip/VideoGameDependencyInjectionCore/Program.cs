﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Security.Authentication.ExtendedProtection;

namespace VideoGameDependencyInjectionCore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // HeroThatOnlyUsesSwords hero1 = new HeroThatOnlyUsesSwords("Ultraman");
            // hero1.Attack();
            // Console.WriteLine();

            // HeroThatCanUseAnyWeapon hero2 = new HeroThatCanUseAnyWeapon("Eregon", new Sword("Brisinger"));
            // hero2.Attack();
            // Console.WriteLine();

            // HeroThatCanUseAnyWeapon hero3 = new HeroThatCanUseAnyWeapon("The Joker", new Grenade("The Pineapple"));
            // hero3.Attack();
            // Console.WriteLine();

            // HeroThatCanUseAnyWeapon hero4 = new HeroThatCanUseAnyWeapon("GI Joe", new Gun("Six shooter",
            // new List<Bullet> { 
            //     new Bullet("Silver Slug", 10),
            //     new Bullet("Lead Ball", 20),
            //     new Bullet("Rusty Nail", 3),
            //     new Bullet("Hollow Point", 5)

            // }));
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            // hero4.Attack();
            ServiceCollection services = new ServiceCollection();

            // all new weapons will now be Grenades by default
            //services.AddTransient<IWeapon, Grenade>(grenade => new Grenade("Exploding Pen"));
            //services.AddTransient<IWeapon, Sword>(s => new Sword("The Sword of Gryffindor"));

            services.AddTransient<IWeapon, Gun>(g => new Gun("Six Shooter",
                new List<Bullet> {
    new Bullet("Silver Slug", 10),
    new Bullet("Lead Ball", 20),
    new Bullet("Rusty Nail", 3),
    new Bullet("Hollow Point", 5)
                }));


            services.AddTransient<IHero, HeroThatCanUseAnyWeapon>(hero => new HeroThatCanUseAnyWeapon("Jonny English", hero.GetService<IWeapon>())
            );

            ServiceProvider provider = services.BuildServiceProvider();


            var hero5 = provider.GetService<IHero>();

            hero5.Attack();
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}