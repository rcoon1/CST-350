﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameDependencyInjectionCore
{
    internal class HeroThatOnlyUsesSwords : IHero
    {
        public string Name { get; set; }
        public HeroThatOnlyUsesSwords(string name)
        {
            Name = name;
        }

        public HeroThatOnlyUsesSwords()
        {
            Name = "Generic Hero. No name given.";
        }

        public void Attack()
        {
            Sword sword = new Sword("Excalibur");
            Console.WriteLine(Name + " prepares himself for the battle.");
            sword.AttackWithMe();
        }
    }
}
