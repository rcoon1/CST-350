﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameDependencyInjectionCore
{
    internal class HeroThatCanUseAnyWeapon : IHero
    {
        public string Name { get; set; }
        public IWeapon MyWeapon { get; set; }
        public HeroThatCanUseAnyWeapon(string name, IWeapon myWeapon)
        {
            Name = name;
            MyWeapon = myWeapon;
        }
        public HeroThatCanUseAnyWeapon()
        {
            Name = "Mr. Nobody. No name provided.";
            MyWeapon = null;
        }

        public void Attack()
        {
            Console.WriteLine(Name + " prepares to attack");
            MyWeapon.AttackWithMe();
        }
    }
}
