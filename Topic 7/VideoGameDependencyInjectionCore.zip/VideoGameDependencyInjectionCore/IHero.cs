﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameDependencyInjectionCore
{
    internal interface IHero
    {
        //hero only needs to do one thing
        void Attack();
    }
}
