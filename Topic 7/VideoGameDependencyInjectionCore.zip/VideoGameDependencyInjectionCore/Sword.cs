﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameDependencyInjectionCore
{
    internal class Sword : IWeapon
    {
        public string SwordName { get; set; }
        public Sword(string SwordName)
        {
            SwordName = SwordName;
        }
        public Sword()
        {
            SwordName = "Lame name sword";
        }

        public void AttackWithMe()
        {
            System.Console.WriteLine(SwordName + " slices through the air, devestating all enemies");
        }
    }
}
